        <footer id="page-footer">
			<div class="content-cont">
                &copy; 2021 Nardcart
			</div>
		</footer>

        <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
        <script  src="<?php echo $path;?>assets/js/index.js"></script>
        
    </body> 
    
</html>