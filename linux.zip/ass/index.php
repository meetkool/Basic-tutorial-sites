
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <center><p style="color: #4267B2; font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif; font-size: 80px;"><b>facebook</b></p>
    
           <p style="font-size:20px;"><b>Create a new account</b></p>It's quick and easy.
           <hr style="width: 30%;">

           <table >
               <tr>
                   <td colspan = "1.5"><input type="text" placeholder="First Name"></td>
                   <td colspan = "1.5"><input type="text" placeholder="Last Name"></td>
               </tr>
               <tr>
                   <td colspan = "3" ><input type="text" size="64" placeholder="Mobile Number or Email address"></td>
               </tr>
               <tr>
                <td colspan = "3" ><input type="password" size="64" placeholder="New password"></td>
               </tr>
           </table>

           <table>
            <tr>
                <td style="font-size: 11px;position: relative; right: 5ch;">Date Of Birth</td>
            </tr>
            
            <tr style="position: relative; right: 3ch">
                <td style="width: 41%;" colspan="1">
                    <select style="width: 100%;" name="" id="">

                 <option value="1">1</option>
                 <option value="2">2</option>
                 <option value="3">3</option>
                 <option value="3">4</option>
                 <option value="3">5</option>
                 <option value="3">6</option>
                 <option value="3">7</option>
                 <option value="3">5</option>


        
                    </select>
                    </td>
                  <td style="width: 41%;" colspan = "1">
                     <select style="width: 100%;" name="" id="">

                  <option value="1">Jan</option>
                  <option value="2">Feb</option>
                  <option value="3">March</option>
         
                     </select>
                  </td>
                  <td style="width: 41%;" colspan = "1">
                 <select style="width: 200%;" name="" id="">

                  <option value="1">2022</option>
                  <option value="2">2021</option>
                  <option value="3">2020</option>
         
                     </select>
                  </td>
            </tr>
           </table>

           <table>
            <tr>
                <td style="font-size: 11px;position: relative; right: 14ch;">Gender</td>
            </tr>
            
            <tr>
                <td><input type="radio" id="fem" name="gender"><label style="width: 33%;" for="fen">Female</label></td>
                <td><input type="radio" id="mal" name="gender"><label for="mal">Male</label></td>
                <td><input type="radio" id="cus" name="gender"><label for="cus">Custom</label></td>
            </tr>
           </table>

           <p style="font-size: 11px;">By clicking Sign Up, you agree to our <a href="https://www.facebook.com/legal/terms/update">Terms</a>, <a href="https://www.facebook.com/about/privacy/update">Data Policy</a> and <a href="https://www.facebook.com/policies/cookies/">Cookie Policy</a>.<br>You may receive SMS notifications from us and can opt out at any time</p>
           <input type="submit" style="color:white; background-color:darkgreen  ;" value="Sign Up">
            <br>
           <a href="https://www.facebook.com/login/?privacy_mutation_token=eyJ0eXBlIjowLCJjcmVhdGlvbl90aW1lIjoxNjQxMDI0MzY3LCJjYWxsc2l0ZV9pZCI6MjY5NTQ4NDUzMDcyMDk1MX0%3D">Already have an<br> account?</a>

           

    </center>
</body>
</html>